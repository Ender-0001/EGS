#include <Windows.h>
#include <iostream>
#include "SDK.hpp"

using namespace SDK;

#include "MinHook/MinHook.h"
#pragma comment(lib, "MinHook/minhook.lib")

#include "Offsets.hpp"
#include "Globals.hpp"
#include "Beacons.hpp"

enum EBeaconState
{
    AllowRequests,
    DenyRequests
};

template<typename T>
T* FindObject(std::string_view type, std::string_view name)
{
    for (int i = 0; i < UObject::GetGlobalObjects().Num(); ++i)
    {
        auto object = UObject::GetGlobalObjects().GetByIndex(i);

        if (object == nullptr)
            continue;

        if (object->GetFullName().find("F_Med_Head1") == std::string::npos)
        {
            if (object->GetFullName().rfind(type, 0) == 0 && object->GetFullName().find(name) != std::string::npos)
                return static_cast<T*>(object);
        }
    }

    return nullptr;
}

DWORD MainThread(LPVOID lpParam)
{
    while (true)
    {
        if (GetAsyncKeyState(VK_SPACE) & 0x8000)
        {
            
        }

        Sleep(1000 / 60);
    }
}

unsigned long __stdcall Main(void*)
{
    AllocConsole();

    FILE* pFile;
    freopen_s(&pFile, "CONIN$", "r", stdin);
    freopen_s(&pFile, "CONOUT$", "w", stderr);
    freopen_s(&pFile, "CONOUT$", "w", stdout);

    MH_Initialize();
    Globals::Init();
    /*auto Console = UConsole::StaticClass()->CreateDefaultObject<UConsole>();
    Console->Outer = Globals::LocalPlayer->ViewportClient;

    Globals::LocalPlayer->ViewportClient->ViewportConsole = Console;

    MessageBoxA(NULL, "Press okay when the loading bar is ready", "EGS V2", MB_OK);*/
    Beacons::Init();

    auto Beacon = SpawnActor<AOnlineBeaconHost>(AOnlineBeaconHost::StaticClass(), { 0, 0, 10000 }, {});
    Beacon->ListenPort = 7777;

    Beacons::InitHost(Beacon);
    Beacon->BeaconState = EBeaconState::AllowRequests;

    TArray<AActor*> OutActors;
    Globals::GameplayStatics->STATIC_GetAllActorsOfClass(Globals::World, APlayerPawn_Athena_C::StaticClass(), &OutActors);
    Globals::Pawn = static_cast<APlayerPawn_Athena_C*>(OutActors[0]);

    if (Globals::Pawn)
    {
        Globals::PlayerController->Possess(Globals::Pawn);

        auto PlayerState = reinterpret_cast<AFortPlayerStateAthena*>(Globals::PlayerController->PlayerState);
        PlayerState->TeamIndex = EFortTeam::HumanPvP_Team1;
        PlayerState->OnRep_TeamIndex();

        Sleep(2000);

        Globals::PlayerController->ServerReadyToStartMatch();
        static_cast<AGameMode*>(Globals::World->AuthorityGameMode)->StartMatch();
    }
    else
        MessageBoxA(NULL, "Invalid PlayerPawn", "EGS V2", MB_OK);

    //CreateThread(0, 0, MainThread, 0, 0, 0);

    return 0;
}

int __stdcall DllMain(void* hModule, unsigned long dwReason, void* lpReserved)
{
    if (dwReason == 1)
        CreateThread(0, 0, Main, 0, 0, 0);

    return 1;
}
